Reasonable Inventory Weight for True Stalker;

This mod makes it so that the player starting inventory is set to 50 kg for all difficulty levels.
After 50 kg you can not walk anymore.
You can increase the amount of weight you can carry with items, suits, backpacks, upgrades and artifacts in the game.

Also, you can choose the files for 60 kg, 75 kg or 100 kg from the folders.

====================
Installation;
====================
1) Edit the "fsgame.ltx" file and change line seven to "$game_data$ = true | true".
2) Extract the "gamedata" folder and copy it into the True Stalker installation directory.
