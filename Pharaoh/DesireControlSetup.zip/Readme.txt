Pharaoh Desire Control 
for "Pharaoh" a Sierra On-Line, Inc / Impression Games product
Version 1.0
Author: Paul Uraeus
Readme File
March 3, 2000

*****************************************************************************

                             TABLE OF CONTENTS

                  I.  INTRODUCTION
                 II.  INSTALLATION AND UNINSTALLATION
                III.  GENERAL TECHNICAL ISSUES
                 IV.  GENERAL PROGRAM ISSUES
                  V.  CONTACTING THE AUTHOR


=-=-=-=-=-=-=-=
I. INTRODUCTION
=-=-=-=-=-=-=-=
        Pharaoh Desire Control is a program which allows you easily design
and test your city block layouts. The program calculates the exact
desirability matrix and shows it in a numeric overlay on the map. In addition
it displays the cost of all structures on a currently selected difficulty
level and the amount of workers they will need in order to function properly.
If you place the housing structures on the map the program will calculate
the maximum population you may reach with these buildings and you may check
the maximum tax income with a specified tax rate and difficulty level. Also
the program has the table of all housing levels and what they need in order
to evolve to that level. The graphical interface is exactly as in the
game "Pharaoh" itself. For those who played "Pharaoh" it won't be a hard task
to use this program. The maximum map width and height - 300X300. I could make
it bigger but I thought it would be enough. The idea was taken from "Pharaoh
Desirability Calculator" by Andy Antoniewicz.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
II. INSTALLATION AND UNINSTALLATION
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        To Install:
        Run the setup.exe and follow the instructions.

        To Uninstall:
        Use the standard uninstall feature "Add/Remove Programs"
        in the Control Panel.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
III. GENERAL TECHNICAL ISSUES
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
        Currently known limitations:
The program doesn't run correctly when the desktop resolution set to
1024 X 768, Large fonts.

=-=-=-=-=-=-=-=-=-=-=-=-=-
IV. GENERAL PROGRAM ISSUES
=-=-=-=-=-=-=-=-=-=-=-=-=-
1. Launching "Pharaoh Desire Control".
        Click on the Windows START menu.
        Select PROGRAMS
        Select PHARAOH DESIRE CONTROL
        Select PHARAOH DESIRE CONTROL (Program File)

2. Placing a structure on the map.
        Click on the item from the menubar on the right side of the screen.
        Choose the structure from the pop-up list.
        Place the structure on an empty place on the map.
        For "Roads", "Gardens" and "Plazas" you may hold the button pressed
        to place the multiple items on the map.

3. Rotating the Temple Complex.
        To rotate the Temple Complex press 'R' on the keyboard.

4. Removing a structure from the map.
        Click on the CLEAR LAND icon in the menubar.
        Click on the structure you want to remove.
        Hold the button pressed to remove multiple structures.

5. Grid.
        To toggle grid on/off:
        Select VIEW from the program's menu.
        Click on SHOW GRID.
        Or
        Press Ctrl-G on the keyboard.

6. Desire Overlay.
        To toggle desire overlay on/off:
        Select VIEW from the program's menu.
        Click on SHOW DESIRE OVERLAY.
        Or
        Press Ctrl-D on the keyboard.

7. Saving and Opening saved maps.
        Use the standard Windows proccess through the program's menu.
        Grid and Desire Overlay status also saved in a file.

8. Changing Difficulty Level.
        Select SETTINGS from the program's menu.
        Select DIFFICULTY.
        Click on a desired difficulty level.

9. Viewing Tax Income.
        Select TOOLS from the program's menu.
        Click on TAX INCOME.
        Adjust your tax rate by moving the slider or by entering the
        value in the Tax Rate field.
        Year Tax Income should be shown in the Tax Income field.

10. Viewing Housing Levels Info.
        Selcet TOOLS from the program's menu.
        Click on HOUSING LEVELS.
        Select the housing type from the list on the right.
        The housing level info and its picture should be shown on the left.
        About the Entertainment Points read the Entertainment.txt.

NOTES:
        The 'Fort' size is 4X4 and not like in the game itself.
        (It's a current limitation of the "ShowMap" function.)
        'Gate House' was not added to the Military Structures.

=-=-=-=-=-=-=-=-=-=-=-=-
V. CONTACTING THE AUTHOR
=-=-=-=-=-=-=-=-=-=-=-=-
        For bug reports, comments and questions contact me at:
        paul_rz@yahoo.com

-----------------------------------------------------------------------------
END OF FILE
